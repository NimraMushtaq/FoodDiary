package com.midterm.fooddiary.Listeners;

public interface RecipeClickListener {
    void onRecipeClicked(String id);
}
