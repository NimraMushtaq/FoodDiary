package com.midterm.fooddiary.Models;

public class Metric {
    public double amount;
    public String unitShort;
    public String unitLong;
}
