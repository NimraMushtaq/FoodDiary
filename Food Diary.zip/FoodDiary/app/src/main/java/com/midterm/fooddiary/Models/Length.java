//The purpose of the Length class is to represent a length measurement. It is used to store information about a length value, including the numerical value and the unit of measurement.
package com.midterm.fooddiary.Models;

public class Length {
    public int number;
    public String unit;
}
