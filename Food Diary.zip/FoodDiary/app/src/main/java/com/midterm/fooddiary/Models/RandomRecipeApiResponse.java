package com.midterm.fooddiary.Models;

import java.util.ArrayList;

public class RandomRecipeApiResponse {
    public ArrayList<Recipe> recipes;
}
