package com.midterm.fooddiary.Models;

public class Temperature {
    public double number;
    public String unit;
}
