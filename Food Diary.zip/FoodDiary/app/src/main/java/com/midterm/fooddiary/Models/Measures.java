package com.midterm.fooddiary.Models;

public class Measures {
    public Us us;
    public Metric metric;
}
